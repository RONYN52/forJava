package user;

public class User {

}
