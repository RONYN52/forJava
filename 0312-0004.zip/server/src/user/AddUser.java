package user;

import java.io.Serializable;
import java.util.Arrays;

public class AddUser implements Serializable {
	private static final long serrialVersionUID=1L;
	private String name;
	private String pass;
	private String age;
	private String phone;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
	public AddUser(String name, String pass, String age, String phone) {
		this.name=name;
		this.pass=pass;
		this.age=age;
		this.phone=phone;
	}
	@Override
	public String toString() {
		return "AddUser [name=" + name + ", pass=" + pass + ", age="
				+ age + ", phone=" + phone + "]";
	}
	

}
