package start;

import java.io.IOException;

import net.Net;

public class Start {

	public static void main(String[] args) throws IOException {
	Net n = new Net("run");	
	n.net();

	}

}
