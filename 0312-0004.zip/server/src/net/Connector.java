package net;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import engine.Engine;
import user.AddUser;

public class Connector implements Runnable{
	private static final String String = null;
	String inMes;
	Socket ssc;
	public Connector(Socket ssc, String inMes) {
		this.ssc=ssc;
		this.inMes=inMes;	
	}

	public void run() {
		try {	
			System.out.println(ssc);
			System.out.println(Thread.currentThread().getName());
			InputStream is = ssc.getInputStream();
			OutputStream os = ssc.getOutputStream();
			PrintWriter writer = new PrintWriter(os);
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			System.out.println(ssc.getLocalPort());
			while(true) {
				while(!reader.ready()) {
					Thread.sleep(1000);
				}
				String line = reader.readLine();
				if ("stop".equals(line)) {
					break;
				}
				if (ssc.getLocalPort() == 8081) {
					System.out.println("Connect client over 8081 for engine");
					Engine en = new Engine(line);
					String str;
					str = en.engine();
					if (str!=null)
					writer.println(str);
					if (str==null)
						writer.println("Error");
				}
				else if (ssc.getLocalPort() == 8080) {
					System.out.println("Connect client over 8080 for login");
					FileInputStream fileInputStream = new FileInputStream("udb.fdb");
				       ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);

				       AddUser addUser = (AddUser) objectInputStream.readObject();
				       String subStr=addUser.toString();
				       String nameSer;
				       String passSer;
				       String name;
				       String pass;
				       nameSer=subStr.substring(subStr.indexOf("name=")+5, subStr.indexOf("pass=")-2);
				       passSer=subStr.substring(subStr.indexOf("pass=")+5, subStr.indexOf("age=")-2);
				       name=line.substring(0, line.indexOf("^"));
				       pass=line.substring(line.indexOf("^")+1, line.length());
				       System.out.println("nameSer :"+nameSer+"- passSer :"+passSer+"- name :"+name+"- pass :"+pass);
				       if ((nameSer.equals(name)) & (passSer.equals(pass)))
					writer.println("loginTrue");
				       else writer.println("loginFalse");
				}
				else if (ssc.getLocalPort() == 8082) {
					System.out.println("Connect client over 8082 for add user");
					String name;
					String pass;
					String age;
					String phone;
					String subLine=line;
					name=subLine.substring(0, subLine.indexOf("^"));
					subLine=subLine.substring(subLine.indexOf("^")+1, subLine.length());
					pass=subLine.substring(0, subLine.indexOf("^"));
					subLine=subLine.substring(subLine.indexOf("^")+1, subLine.length());
					age=subLine.substring(0, subLine.indexOf("^"));
					subLine=subLine.substring(subLine.indexOf("^")+1, subLine.length());
					phone=subLine;
					System.out.println(name);
					System.out.println(pass);
					System.out.println(age);
					System.out.println(phone);
					
					AddUser addUser = new AddUser(name, pass, age, phone);

				       FileOutputStream outputStream = new FileOutputStream("udb.fdb", true);
				       ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);

				       
				       objectOutputStream.writeObject(addUser);
				       objectOutputStream.close();
				       writer.println("addUser");
				}
				writer.flush();
					
		}
			
			writer.close();
			reader.close();
			os.close();
			is.close();
			ssc.close();
			
			
		} catch (IOException | InterruptedException | ClassNotFoundException e) {
			try {
				ssc.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}
}
