package net;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Net {
	String inMes;
	String outMes;
	public Net(String in) {
		inMes=in;
		
	}
	public void net() throws IOException {
		ServerSocket ssu;
		ServerSocket ssd;
		ServerSocket sse;
		ssu = new ServerSocket(8080);
		ssd = new ServerSocket(8081);
		sse = new ServerSocket(8082);
		System.out.println("Waiting...");
		
		// while(true) {
			 
		 new Thread(new Acc(ssu,inMes)).start();
		 new Thread(new Acc(ssd,inMes)).start();
		 new Thread(new Acc(sse,inMes)).start();
		
		
		// }
			
		
	}
	public class  Acc implements Runnable{
		ServerSocket ss;
		String inMes;
		public Acc(ServerSocket ss,String inMes) {
			this.ss=ss;
			this.inMes=inMes;
		}
		public void run() {
		
			Socket ssc = null;
			System.out.println(Thread.currentThread().getName());
			while (true) {
					while (true) {
				try {
					ssc = ss.accept();
					new Thread(new Connector(ssc, inMes)).start();
					System.out.println("Run thread connector "+ssc.getLocalPort());
				} catch (IOException e) {

					e.printStackTrace();
				}
					}
			}

		}
		
	}

}
