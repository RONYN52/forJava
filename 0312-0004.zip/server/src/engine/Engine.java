package engine;

public class Engine {
	String expres;
	public Engine(String expres) {
		this.expres=expres;
	}
	public String engine() {
		String total=null;
		String [] expresArray;
		expresArray=strToArray(expres);
		
				
				Priority prio = new Priority(expresArray);
				total=prio.priority();
				System.out.println(total);
			
		return total;
	}
	
	public static String[] strToArray(String expres) {
		String[] result=new String[expres.length()];
		int i = 0,j=0,k=0;
		  String buf="";
		  while (i<result.length)  {
			  TypeS ts = new TypeS(expres.substring(i, i+1));
			  j=i+1;
			  if ((ts.typeS(expres.substring(i, i+1))==true)  & (i<result.length+1)) {
				  buf=buf+expres.substring(i, i+1);
				  if ((j+1)<result.length)
				 while  ((ts.typeS(expres.substring(j, j+1))==true) & (j<result.length+1))  
				 {
					buf=buf+expres.substring(j, j+1);
				j=j+1;
				 }
					i=j;
					result[k]=buf;
					k++;
					buf="";
			  } else if (k<result.length) {
				  result[k]=expres.substring(i, i+1);
				  k++;
				  i=j;
			  } else break;
		  
	} for (int s=0;s<result.length;s++) {
		}
		  return result;
		
	}

}
