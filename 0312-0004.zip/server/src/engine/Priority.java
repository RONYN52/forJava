package engine;

import engine.Enum.e;

public class Priority {
	String [] sumA;
	public static String tot=null;
	public Priority(String bufA[]){
		sumA=bufA;
		}
public String priority() {
	String result="";
	int size=0;
	if (sumA.length==1) {
		result=sumA[0];
		return result;
	}
	
	for (int i=0;i<sumA.length;i++) {
	if (sumA[i]!=null) size++;	
	}
	String [] sumB = new String [size];

	for (int i=0;i<sumB.length;i++)
		sumB[i]=sumA[i];
	String [] sumC = new String [3];
	sumC=protos(sumB);
	System.out.println("Return resive : "+sumC[0]+sumC[1]+sumC[2]+" len "+sumC.length+"  Why?");
	result=sumC[0];
	
	return result;

}
public String[] revolve(String revA[]) {
	int size=0;
	String [] revB  = new String[revA.length];
	for (int i=0;i<revB.length;i++) {
	revB[i]=revA[i];
	}
	if (revA.length==1)	return revA;
	for (int i=0;i<revB.length;i++) {

//	if (revA[i].equals(e.LBKT.getZnak())==true) {
//	while (revA[i+1].equals(e.RBKT.getZnak())==true) if (i<revA.length-1) revB[i]=revA[i]; 
//	for (int d=0;d<revB.length;d++) System.out.print(revB[d]+" % ");
//	revolve(revB);
//}
		if ((revB[i]==null) & (revB.length>0)) revB=cleanBuf(revB);
		if (revB.length>2)
			if (i>0)
		if (revB[i].equals(e.MULTIPLY.getZnak())) {
		float x=0; float y=0;
		x=Float.valueOf(revB[i-1]); y=Float.valueOf(revB[i+1]);
		Multiply mu = new Multiply(x,y);
		revB[i]=String.valueOf(mu.multiply());
		revB[i-1]=null;
		revB[i+1]=null;
		if (revB.length>1)
		revB=cleanBuf(revB);
		if (revB.length>1) {
			if (revB.length==3) {
				if (revB[1].equals(e.MULTIPLY.getZnak())) revB=revolve(revB);
			return revB;	
			} else {
		revB=revolve(revB);
		}
		} else {
			return revB;	
		}
		
	}
		if ((revB[i]==null) & (revB.length>0))  revB=cleanBuf(revB);
		if (revB.length>2)
			if (i>0)
	if (revB[i].equals(e.DIVIDE.getZnak())) {
		float x=0; float y=0;
		x=Float.valueOf(revB[i-1]); y=Float.valueOf(revB[i+1]);
		Divide di = new Divide(x,y);
		revB[i]=String.valueOf(di.divide());
		revB[i-1]=null;
		revB[i+1]=null;
		if (revB.length>1)
			revB=cleanBuf(revB);
		if (revB.length>1) {
			if (revB.length==3) {
				if (revB[1].equals(e.DIVIDE.getZnak())) revB=revolve(revB);
			return revB;	
			} else {
		revB=revolve(revB);
		}
		} else {
			return revB;	
		}
	}
	
	
	}
	
	
	return revB;
}
public String[] cleanBuf(String revA[]) {
	System.out.println("in");
	int size=0;
	if (revA.length==1)
		return revA;

	if (revA.length==3) if (revA[0]==null) if (revA[2]==null) {
		String[] revB = new String[1];
		revB[0]=revA[1];
		return revB;
	} 
	if (revA.length==3) if (revA[0]!=null) if (revA[2]!=null) {
		return revA;
	} 
	
	for (int j=0;j<revA.length;j++) {
		if (revA[j]!=null) 
			size++;	
		}
		
	String[] revB = new String[size];
	int l=0;
	
	for (int m=0;m<revA.length;m++) {
		if(revA[m]!=null) {	
		revB[l]=revA[m];
		System.out.println("RevB l "+revB[l]);
			l++;
		} 
	}
		

		
	return revB;
}
public String[] protos(String revA[]) {
	String [] revB  = new String[revA.length];
	revB=revA;

	if (revA.length==1) return revA;
			if (revA.length == 3) {
				String[] revC = new String[1];
				if (revB[1].equals(e.MINUS.getZnak())) {
					float x;
					float y;
					x = Float.valueOf(revB[0]);
					y = Float.valueOf(revB[2]);
					Minus mi = new Minus(x, y);
					revC[0] = String.valueOf(mi.minus());
					System.out.println("m3 "+revC[0]);
					return revC;
				}
				if (revB[1].equals(e.PLUS.getZnak())) {
					float x;
					float y;
					x = Float.valueOf(revB[0]);
					y = Float.valueOf(revB[2]);
					Plus pl = new Plus(x, y);
					String str;
					str = String.valueOf(pl.plus());
					System.out.println("Befor sending  "+str);
					String[] rev = new String[1];
					rev[0]=str;
					System.out.println("Size [0] array  "+rev.length+"  Value array[0] element "+rev[0]+" return... send");
					return rev;
				}
				System.out.print("TOTAL = " + revC[0] + "\n"+"length: "+revC.length+"\n");
				tot=revC[0];
				
		}
		if (revB[0]!=null) { 
				for (int i = 0; i < revB.length; i++) {
					if (revB[i] == null)
						revB = cleanBuf(revB);
					if (revB.length > 2)
						if (revB[i].equals(e.MINUS.getZnak())) {
							float x;
							float y ;
							x = Float.valueOf(revB[i - 1]);
							y = Float.valueOf(revB[i + 1]);
							Minus mi = new Minus(x, y);
							revB[i] = String.valueOf(mi.minus());
							revB[i - 1] = null;
							revB[i + 1] = null;
							System.out.println("m");
							if (revB.length > 1)
								revB = cleanBuf(revB);
							if (revB.length == 1)
								return revB;
							if (revB.length > 2)
								protos(revB);

	}
				//	if (i==revB.length) System.exit(0);
					if (i==revB.length) { 
						String[] revC = new String[1];
						revC[0]=tot;
						return revC;} 
	if (revB[i]==null) revB=cleanBuf(revB);
	if (revB.length>2)
		if (i>0)
			if (i<revB.length)
	if (revB[i].equals(e.PLUS.getZnak())) {
		float x; 
		float y;
		x=Float.valueOf(revB[i-1]); y=Float.valueOf(revB[i+1]);
		Plus pl = new Plus(x,y);
		revB[i]=String.valueOf(pl.plus());
		revB[i-1]=null;
		revB[i+1]=null;
		System.out.println("p");
		if (revB.length>1)
		revB=cleanBuf(revB);
		if (revB.length==1) return revB;
		if (revB.length>2)
		protos(revB); 
	} 
	}
	
}  
	return revB; 
}
}

