package engine;

public class TypeS {
	String str;
	TypeS(String inStr){
		str=inStr;
	}
	public boolean typeS(String str){
		if (("+").equals(str) | ("-").equals(str) | ("*").equals(str) | ("/").equals(str) | ("(").equals(str) | (")").equals(str)) {		
		return false; }
		else  {
			return true;
		}
	}

}
