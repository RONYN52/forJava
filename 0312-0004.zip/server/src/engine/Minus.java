package engine;

public class Minus {
	float x;
	float y;
	float result;
	Minus(float a, float b){
		x=a;
		y=b;
		result=x-y;
	}
	float minus() {
		return result;		
	}
}
