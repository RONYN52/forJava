package engine;

public class Multiply {
	float x;
	float y;
	float result;
	Multiply(float a, float b){
		x=a;
		y=b;
		result=a*b;
	}
	float multiply(){
		return result;
	}
}
