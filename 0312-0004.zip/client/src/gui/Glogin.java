package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.ParseException;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.text.MaskFormatter;

import net.Net;

public class Glogin {
	public static void createGUI() {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame loginFrame = new JFrame("Please, input login/password...");
		loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel topPan = new JPanel();
		JPanel botPan = new JPanel();
		JTextField loginText = new JTextField();
		JPasswordField passText = new JPasswordField();
		JLabel loginLabel = new JLabel();
		JLabel passLabel = new JLabel();
		JButton signinBut = new JButton("Sign in");
		JButton signupBut = new JButton("Sign up...");
		
		loginLabel.setText("Login: ");
		passLabel.setText("Password: ");
		loginFrame.setLayout(new BorderLayout());
		topPan.setLayout(new GridLayout(2,2));
		topPan.add(loginLabel, BorderLayout.WEST);
		topPan.add(passLabel, BorderLayout.EAST);
		topPan.add(loginText);
		topPan.add(passText);
		botPan.setLayout(new BorderLayout());
		loginFrame.add(topPan, BorderLayout.NORTH);
		loginFrame.add(botPan, BorderLayout.SOUTH);
		botPan.add(signinBut, BorderLayout.WEST);
		botPan.add(signupBut, BorderLayout.EAST);
		
		
		class MyAL implements ActionListener{
			String umes="";
			
			public void actionPerformed(ActionEvent event) {
				if ("Sign in".equals(event.getActionCommand())==true) {
					if ((loginText.getText().length()!=0)||(passText.getText().length()!=0)) {
					umes="#"+loginText.getText()+"^"+passText.getText();
					Net net = new Net(umes);
					try {
						if ("loginTrue".equals(net.net())) {
						gui.Gcalcutta.createGUI();	
						loginFrame.setVisible(false);
						} else {
							JOptionPane.showOptionDialog(null,"Wrong login or password!",umes, JOptionPane.DEFAULT_OPTION,0,null,null,net);
						}
						
					} catch (IOException | HeadlessException | InterruptedException e) {
						
						e.printStackTrace();
					}
					} else {
						JOptionPane.showOptionDialog(null,"Login or password is empty! Please input login and password!",umes, JOptionPane.DEFAULT_OPTION,0,null,null,null);
					}
				}
				
			
				if ("Sign up...".equals(event.getActionCommand())==true) {					
			Gadd gAdd = new Gadd();
			gAdd.createGUI();
					
				}
		}
		}	
		ActionListener al = new MyAL();
		signinBut.addActionListener(al);
		signupBut.addActionListener(al);
		
		loginFrame.setPreferredSize(new Dimension(450,150));
		loginFrame.setLocation(750, 150);
		loginFrame.pack();
		loginFrame.setVisible(true);
				
	}

}
