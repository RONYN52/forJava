package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import net.Net;

public class Gadd {
	public void createGUI() {
		JFrame.setDefaultLookAndFeelDecorated(true);
		JFrame addFrame = new JFrame("Please, input user data...");
		addFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel topPan = new JPanel();
		JPanel botPan = new JPanel();
		JTextField loginText = new JTextField();
		JTextField ageText = new JTextField();
		JTextField phoneText = new JTextField();
		JPasswordField passText = new JPasswordField();
		JLabel loginLabel = new JLabel();
		JLabel passLabel = new JLabel();
		JLabel ageLabel = new JLabel();
		JLabel phoneLabel = new JLabel();
		JButton signinBut = new JButton("Save");
		JButton signupBut = new JButton("Cancel");
		
		loginLabel.setText("Login: ");
		passLabel.setText("Password: ");
		ageLabel.setText("Age:");
		phoneLabel.setText("Phone number:");
		addFrame.setLayout(new BorderLayout());
		topPan.setLayout(new GridLayout(2,2));
		topPan.add(loginLabel, BorderLayout.WEST);
		topPan.add(passLabel, BorderLayout.EAST);
		topPan.add(ageLabel, BorderLayout.WEST);
		topPan.add(phoneLabel, BorderLayout.EAST);
		topPan.add(loginText);
		topPan.add(passText);
		topPan.add(ageText);
		topPan.add(phoneText);
		botPan.setLayout(new BorderLayout());
		addFrame.add(topPan, BorderLayout.NORTH);
		addFrame.add(botPan, BorderLayout.SOUTH);
		botPan.add(signinBut, BorderLayout.WEST);
		botPan.add(signupBut, BorderLayout.EAST);
		
		class MyAL implements ActionListener{	
			String umes="";
			public void actionPerformed(ActionEvent event) {
				if ("Save".equals(event.getActionCommand())==true) {
				umes="&"+loginText.getText()+"^"+passText.getText()+"^"+ageText.getText()+"^"+phoneText.getText();
				Net net = new Net(umes);
				try {
					net.net();
				} catch (IOException | InterruptedException e) {
					e.printStackTrace();
				}
				addFrame.setVisible(false);
				}
				if ("Cancel".equals(event.getActionCommand())==true) {
			
				addFrame.setVisible(false);	
				}
		}
		}
		
		ActionListener al = new MyAL();
		signinBut.addActionListener(al);
		signupBut.addActionListener(al);
		
		addFrame.setPreferredSize(new Dimension(550,180));
		addFrame.setLocation(750, 150);
		addFrame.pack();
		addFrame.setVisible(true);
	}

}
