package net;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Net {
	String inMes;
	String outMes;
	String ipAddr;
	
	public Net(String in) {
		this.inMes=in;
	}

	public String net() throws IOException, InterruptedException {
		File file = new File("net.txt");
		if (file.exists() == true) {
			try {
				ipAddr=(Files.readAllLines(Paths.get("net.txt"), StandardCharsets.UTF_8)).get(0);
				System.out.println(ipAddr);
			} catch (IOException e) {

				e.printStackTrace();
			}
		} else {
			file.createNewFile();
			Files.write(Paths.get("net.txt"), "127.0.0.1".getBytes());
			ipAddr = "127.0.0.1";
		}
		Socket cs;
		if ("#".equals(inMes.substring(0, 1))) {
			cs = new Socket(ipAddr, 8080);
			inMes = inMes.substring(1, inMes.length());
		} else if ("&".equals(inMes.substring(0, 1))) {
			cs = new Socket(ipAddr, 8082);
			inMes = inMes.substring(1, inMes.length());
		} else {
			cs = new Socket(ipAddr, 8081);
			
		}
		InputStream is = cs.getInputStream();
		OutputStream os = cs.getOutputStream();
		PrintWriter writer = new PrintWriter(os);
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));

		while (true) {
			writer.println(inMes);
			writer.flush();
			while (!reader.ready()) {
				Thread.sleep(1000);
			}
			String answer = reader.readLine();
			outMes = answer;
			if (answer!=null) {
				break;
			}
			
		}
				  
			 
		reader.close();
		writer.close();
		is.close();
		os.close();
		cs.close();
			return outMes;
		}
		
	

}
