package cache;

import java.io.IOException;

import net.Net;

public class Sender {
	String send, resiv;
	
	Sender(String forSend){
		send=forSend;
		resiv="";
	}

	public String sender() throws IOException, InterruptedException {
		Net net = new Net(send);
		resiv=net.net();
		return resiv;
	}
	
}
