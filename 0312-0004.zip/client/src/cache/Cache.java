package cache;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class Cache {
	final int CACHE_SIZE=10;
	String expres;

	Deque<Member> cL1 = new ArrayDeque<Member>(CACHE_SIZE);
	LinkedHashMap<String,String> cL2 = new LinkedHashMap<String,String>();   // ��� �������������� ��������� ����������?
	
	public Cache(String exp) {  
		expres=exp;
				
	 }
		
	 public String cache() throws IOException, InterruptedException{
		String result="";
		
		for (Member el1:cL1) {
			if (el1.exp.equals(expres)==true) result=el1.val;	
			}	
		if (cL1.contains(expres)==true){      			 // if exists in L1
			cL1.getFirst();
			
			for (Member el1:cL1) {
			if (el1.exp.equals(expres)==true) result=el1.val;	
			}	
			System.out.println("Cache L1 expression: "+expres+" ; value; "+result);
		} else if (cL2.containsKey(expres)==true) {  	 // if exists in L2
			Set<Map.Entry<String,String>> set = cL2.entrySet(); 
			for (Map.Entry<String, String> sg:set) {
				if (sg.getKey()==expres) result=cL2.get(sg.getValue());		
			}
			System.out.println("Cache L2 expression: "+expres+" ; value; "+result);
		
		} else											// if not found Lx
		{
			Sender sen = new Sender(expres);
			result=sen.sender();
			if (cL1.size()>(CACHE_SIZE-1)) {     		// if Queue in full volume
			cL2.put(cL1.getLast().exp, cL1.getLast().val);	
			cL1.addFirst(new Member (expres,result));
			System.out.println("Full L1, add to L2 expression: "+expres+" ; value; "+result);
			} else {
				cL1.addFirst(new Member (expres,result));	
				System.out.println("No Full L1: "+expres+" ; value; "+result);
				
			}
			
			//cL1.put(expres, result);
		}
		
		return result;
	}
static class Member {
	String exp;
	String val;
	Member(String e1, String v1){
	exp=e1;
	val=v1;
	}
	
	
}
} 
