package net;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Connector extends Thread{
	private String ipAddr;
	private String msg;
	public Connector(String ipAddr, String msg) throws UnknownHostException, IOException {
		this.ipAddr=ipAddr;
		this.msg=msg;
		
		
	}
	
	public void run(){
		/*Socket cs;
		   try {
		if ("#".equals(msg.substring(0,1))) {
			cs =new Socket(ipAddr,8080);
			} else if ("&".equals(msg.substring(0,1))) {
				cs =new Socket(ipAddr,8082);
				msg=msg.substring(1, msg.length()-1);
				} else
			{
			cs = new Socket(ipAddr,8081);
			msg=msg.substring(1, msg.length()-1);
			}
			  
		BufferedReader is = new BufferedReader(new InputStreamReader(cs.getInputStream()));
			    	 
			    	  System.out.println(cs.getPort());			    	 
			    	  os.write(msg);
			    	  os.flush();
			    	  if (is!=null) {
			    		  Net n = new Net(is.toString());
			    		  n.outMes=is.toString();
			    		  
			    	  }
			    	  cs.close();
			    	  } catch (IOException ex) {
			    	  System.err.print(ex);
			    	  } finally {
			    	  //if (cs!=null)  cs.close();
			    	  }

		
		*/
	}

}
