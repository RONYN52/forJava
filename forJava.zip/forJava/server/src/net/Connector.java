package net;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Connector implements Runnable{
	String inMes;
	Socket ssc;
	public Connector(Socket ssc, String inMes) {
		this.ssc=ssc;
		this.inMes=inMes;	
	}

	public void run() {
		try {	
			System.out.println(ssc);
			InputStream is = ssc.getInputStream();
			OutputStream os = ssc.getOutputStream();
			PrintWriter writer = new PrintWriter(os);
			BufferedReader reader = new BufferedReader(new InputStreamReader(is));
			System.out.println(ssc.getLocalPort());
			while(true) {
				writer.println("loginTrue");
				while(!reader.ready()) {
					Thread.sleep(1000);
					System.out.println("reader is ready? "+reader.ready());
				}
				System.out.println("sleep 2000");
				String line = reader.readLine();
				if ("stop".equals(line)) {
					break;
				}
				System.out.println("Connect client over 0000 for 0000");
				if (ssc.getLocalPort() == 8081) {
					System.out.println("Connect client over 8080 for engine");
					writer.println(line);
				}
				else if (ssc.getLocalPort() == 8080) {
					System.out.println("Connect client over 8081 for login");
					writer.println("loginTrue");
				}
				else if (ssc.getLocalPort() == 8082) {
					System.out.println("Connect client over 8082 for add user");
					writer.println("&"+line);
				}
				writer.flush();
					
		}
			
			writer.close();
			reader.close();
			os.close();
			is.close();
			ssc.close();
			
			
		} catch (IOException | InterruptedException e) {
			try {
				ssc.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}
}
