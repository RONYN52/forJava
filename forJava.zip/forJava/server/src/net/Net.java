package net;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Net {
	String inMes;
	String outMes;
	public Net(String in) {
		inMes=in;
		
	}
	public void net() throws IOException {
		ServerSocket ssu;
		//ServerSocket ssd;
		//ServerSocket sse;
		ssu = new ServerSocket(8080);
		//ssd = new ServerSocket(8081);
		//sse = new ServerSocket(8082);
		System.out.println("Waiting...");
		
		 while(true) {
		//Socket ssc = null;	 
		//while (ssc==null) {
			//if (ssu!=null) 
				Socket ssc= ssu.accept();
				System.out.println("accept  client "+ssc.toString());
				System.out.println("accept  server "+ssu.toString());
			//if (ssd!=null) ssc= ssd.accept();
			//if (sse!=null) ssc= sse.accept();
			new Thread(new Connector(ssc,inMes)).start(); 
		//}
		 }
			
		
	}

}
