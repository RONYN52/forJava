package cache;

public class Sender {
	String send, resiv;
	
	Sender(String forSend){
		send=forSend;
		resiv="";
	}

	public String sender(String send) {
		resiv=null;//hm.Calcutta.start(send);
		return resiv;
	}
	
}
