package start;

public class Start {
	public static class Main{
		public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				gui.Glogin.createGUI();
			}
		
	});
	}
}
}