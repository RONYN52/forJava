package net;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Net {
	String inMes;
	String outMes;
	String ipAddr;
	
	public Net(String in) {
		inMes=in;
	}
		public  String net(String inMes) throws IOException {		
			File file = new File("net.txt");
			if (file.exists()==true) {
			try {
				ipAddr=Files.lines(Paths.get("net.txt"), StandardCharsets.UTF_8).toString();
			} catch (IOException e) {
			
				e.printStackTrace();
			}
			} else {
				file.createNewFile();
				Files.write(Paths.get("net.txt"), "127.0.0.1".getBytes());
				ipAddr="127.0.0.1";
			}
			 new Connector(ipAddr,inMes).run(inMes);

			  
			
			return outMes;
		}
		
	

}
