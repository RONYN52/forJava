package start;

import java.io.IOException;

public class Start {

	public static void main(String[] args) throws IOException {
	net.Net n = new net.Net("run");	
	n.net("run");

	}

}
