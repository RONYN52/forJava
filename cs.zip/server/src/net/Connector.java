package net;

import java.net.ServerSocket;
import java.net.Socket;

public class Connector extends Thread{
	String inMes;
	Socket ssc;
	public Connector(Socket ss, String inMes) {
		this.inMes=inMes;
		this.ssc=ss;
	}

	public void run() {
		System.out.println("Connect client over 0000 for 0000");
		if (ssc.getPort() == 8080) {
			System.out.println("Connect client over 8080 for engine");
		}
		if (ssc.getPort() == 8081) {
			System.out.println("Connect client over 8081 for login");
		}
		if (ssc.getPort() == 8082) {
			System.out.println("Connect client over 8082 for add user");
		}
	}
}
