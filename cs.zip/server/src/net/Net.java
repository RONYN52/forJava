package net;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Net {
	String inMes;
	String outMes;
	
	public Net(String in) {
		inMes=in;
		
	}
	public void net(String inMes) throws IOException {
		ServerSocket ssu;
		ServerSocket ssd;
		ServerSocket sse;
		ssu = new ServerSocket(8080);
		ssd = new ServerSocket(8081);
		sse = new ServerSocket(8082);
		 while(true) {
		Socket ssc = null;	 
		while (ssc==null) {
			if (ssu!=null) ssc= ssu.accept();
			if (ssd!=null) ssc= ssd.accept();
			if (sse!=null) ssc= sse.accept();
		}
			new Connector(ssc,inMes).run(); 
			
		 }
			
		
	}

}
