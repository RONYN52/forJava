package hm;

public class Minus {
	float x;
	float y;
	float result;
	Minus(float a, float b){
		x=a;
		y=b;
		result=x-y;
	}
	float minus(float x,float y) {
		return result;		
	}
}
