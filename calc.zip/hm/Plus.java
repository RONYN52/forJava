package hm;

public class Plus {
	float x;
	float y;
	float result;
	Plus(float a,float b){
		x=a;
		y=b;
		result=x+y;
	}
	float plus(float x,float y){
	return result;	
	}
	
}
