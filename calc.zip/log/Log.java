package log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.LineNumberReader;

public   class Log {
	String data; 
	public Log(String instr) {
		data=instr;
		
	}
	public  static void log(String data) throws IOException {
		File file = new File("calcutta.log");
		if (file.exists()==false)
			try {
				file.createNewFile();			
			} catch (IOException e) {
				
				e.printStackTrace();
			}	
		int lineNumber = 0;
		FileReader fnum = new FileReader(file); 
		BufferedReader reader = new BufferedReader(fnum);
		try { 				
			while (reader.readLine() != null){
			lineNumber++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (lineNumber==5) {
			new JThread(true).start();
			try(FileWriter writer = new FileWriter("calcutta.log", true))
	        {
	            writer.write(data); 
	            writer.flush();
	            writer.close();
	        }
		} else {
		     try(FileWriter writer = new FileWriter("calcutta.log", true))
		        {
		            writer.write(data); 
		            writer.flush();
		            writer.close();
		        }
		}
		
		}

}
