package log;

import java.io.File;
import java.io.IOException;

class JThread extends Thread {
    boolean ext=false;
    JThread(boolean extFile){
        ext=extFile;
    }
    @Override  
    public void run(){
    	int i=1;
    	File file = new File("calcutta.log");   
        while (new File("calcutta"+Integer.toString(i)+".log").exists()==true) { 
			i++;
		}
		File fileNew = new File("calcutta"+Integer.toString(i)+".log"); 
		try {
			fileNew.createNewFile();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
      
		file.renameTo(fileNew);
		try {
			file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		} 
         // Thread.sleep(500); // ������ ���
       JThread.interrupted();
       System.out.print("Process thread...");
    }
    
}
